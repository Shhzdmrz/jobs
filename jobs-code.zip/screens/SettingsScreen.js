import React, { Component } from 'react';
import { View, Text } from 'react-native';

class SettingsScreen extends Component{
    render(){
        return(
            <View>
                <Text>==============</Text>
                <Text>==============</Text>
                <Text>==============</Text>
                <Text>Settings Screen</Text>
                <Text>==============</Text>
                <Text>==============</Text>
                <Text>==============</Text>
            </View>
        );
    }
}

export default SettingsScreen;
